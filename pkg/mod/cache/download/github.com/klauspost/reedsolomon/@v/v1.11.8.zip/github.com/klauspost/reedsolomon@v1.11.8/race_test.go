// Copyright 2022, Klaus Post, see LICENSE for details.

//go:build race
// +build race

package reedsolomon

const raceEnabled = true
